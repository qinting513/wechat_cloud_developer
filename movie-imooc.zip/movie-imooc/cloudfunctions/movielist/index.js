
/**
 * request-promise这个三方库：
 * https://github.com/request/request-promise
 * 
   npm install --save request
   npm install --save request-promise
 * 
 * 1.使用豆瓣接口的坑 https://blog.csdn.net/qq_42209630/article/details/80778604#comments
 * 2. 要加APIKey
*/

// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

var rp = require('request-promise');

// 云函数入口函数
exports.main = async(event, context) => {
/*
电影列表API：http://api.douban.com/v2/movie/in_theaters?apikey=0df993c66c0c636e29ecbb5344252a4a&start=0&count=10

电影详情API：`http://api.douban.com/v2/movie/subject/${event.movieid}?apikey=0df993c66c0c636e29ecbb5344252a4a`
*/
  var url = `http://api.douban.com/v2/movie/in_theaters?apikey=0df993c66c0c636e29ecbb5344252a4a&start=${event.start}&count=${event.count}`;
  return rp(url)
    .then(function(res) {
      console.log(res);
      return res;
    })
    .catch(function(err) {
      console.err(err);
    });
}