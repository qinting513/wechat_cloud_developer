export declare const basic: void;
